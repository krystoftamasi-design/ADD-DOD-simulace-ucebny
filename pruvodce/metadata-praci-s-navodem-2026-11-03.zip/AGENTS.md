# Pokyny pro propojení metadat

- Balíček obsahuje pouze data a odkazy; obrázky a videa neobsahuje.
- Před změnami vytvoř zálohu cílových metadat a ručních úprav a porovnej jejich stáří a obsah; existující novější úpravy nepřepisuj.
- Data uchovávej jako oddělené soubory se stejnými názvy a strukturou jako v archivu; `categories.json` patří do aktivní složky aplikace, ostatní soubory do datového adresáře `DOD_DATA_DIR`.
- Původní metadata patří do `prace/showcase-digital-komplet/metadata.json`; původní obrázky mají zůstat vedle nich ve složce `obrazky/`, aby odpovídaly relativním cestám `image.file`.
- Práce propojuj přes `id`: původní známku a tagy z metadat přebij pouze poli existujícími v `upravy-praci.json`; `hiddenImages` skrývá jmenované obrázky.
- Texty z `popisy-praci.json` a asociace z `asociace-praci.json` připojuj podle ID; video a externí odkazy připojuj podle ID z pole `projects` v `projekty-sjednocene.json`.
- Definice kategorií čti z přiloženého `categories.json` aktuální kopie aplikace; porovnej je s cílovou verzí před přepsáním.
- Před nasazením porovnej otisky zdrojů v `overeni.json` a znovu zkontroluj shodu ID, existenci obrázků, platnost ručních úprav a několik konkrétních prací; automatická textová shoda a dostupnost externích odkazů nejsou zárukou relevance ani funkčnosti.
- Balíček je snímek dat; při dalších místních změnách nemusí obsahovat nejnovější úpravy. Nezahrnuje aplikační kód ani lidská hodnocení.
